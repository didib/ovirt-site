'use strict';

(function (mod) {

    mod.controller('tabController', ['$scope', function ($scope) {
        $scope.people = [
            { name: 'John', city: 'Boston' },
            { name: 'Frank', city: 'San Francisco' },
            { name: 'James', city: 'London' },
            { name: 'Bob', city: 'Boston' }
        ];
    }]);

}(
    angular.module('plugin.tab', [])
));